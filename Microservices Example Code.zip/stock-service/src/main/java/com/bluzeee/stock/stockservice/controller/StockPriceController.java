package com.bluzeee.stock.stockservice.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/rest/stock")
public class StockPriceController {
	
	@Autowired private RestTemplate restTemplate;
	
	@SuppressWarnings("unchecked")
	@GetMapping("/")
	public Map<String, Integer> getStockPrice(){
		ResponseEntity<List> responseEntity = restTemplate.exchange("http://db-service/rest/db/", HttpMethod.GET, null, List.class);
		List<String> stocksList = responseEntity.getBody();
		return getPrices(stocksList);

	}

	private Map<String, Integer> getPrices(List<String> stocksList) {
		Map<String, Integer> prices = new HashMap<>();
		
		int i=10;
		stocksList.forEach(e -> prices.put(e, i+1));
		
		return prices;
		
	}

}
