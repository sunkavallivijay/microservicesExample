package com.bluzeee.stock.dbservice.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest/db")
public class StockController {
	
	@GetMapping("/")
	public List<String> getQuotes(){
		return Arrays.asList(new String[] {"a","b","c"});
	}

}
